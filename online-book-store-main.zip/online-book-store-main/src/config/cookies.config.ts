export const cookieKeys = {
  USER_TOKEN: "user_token",
};
